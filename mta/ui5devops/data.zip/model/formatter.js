/*!ui5-devops Wed Jun 10 2020 18:02:33 GMT+0300 (GMT+03:00) */

"use strict";sap.ui.define(["sap/ui/core/format/NumberFormat"],function(t){var a=t.getFloatInstance({maxFractionDigits:5,minFractionDigits:0,groupingEnabled:!1},sap.m.getLocale());return{formatFloatLocal:function(t){return a.format(parseFloat(t))}}});