/*!ui5-devops Wed Jun 10 2020 18:02:33 GMT+0300 (GMT+03:00) */

"use strict";sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(n,i){return{createDeviceModel:function(){var e=new n(i);return e.setDefaultBindingMode("OneWay"),e}}});