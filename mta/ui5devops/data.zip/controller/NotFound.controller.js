/*!ui5-devops Wed Jun 10 2020 18:02:33 GMT+0300 (GMT+03:00) */

"use strict";sap.ui.define(["local/experiment/controller/BaseController"],function(e){return e.extend("local.experiment.controller.NotFound",{onLinkPressed:function(){this.getRouter().navTo("StartPage")}})});