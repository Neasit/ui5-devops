/*!ui5-devops Wed Jun 10 2020 18:02:33 GMT+0300 (GMT+03:00) */

"use strict";sap.ui.define(["sap/ui/core/UIComponent","local/experiment/model/models"],function(e,t){return e.extend("local.experiment.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments),this.setModel(t.createDeviceModel(),"device"),this.getRouter().initialize()}})});